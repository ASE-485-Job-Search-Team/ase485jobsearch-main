---
colorlinks: true
---

# ASE 485 Homework 1 

* 50 points in total
* Use the `Last-First-HW#' directory as a template directory. Copy all your results in the results directory (create sub-directories if necessary) and complete (mark and grade) the grading.docx in the directory. 
* Change the directory name; for example, `Cho-Samuel-HW#` is the directory name if I submit the homework (# should be replaced with the HW number). Notice that last name comes first. 
* Zip the directory to make a zip file, for example, `Cho-Samuel-HW#.zip` (# should be replaced with the HW number), to submit them on Canvas. 

Also, notice the following:

* You should **make the installation documentation page in the Notion app** for your future use. 
  * You can make a markdown file and store the file in the Notion app.
* You should use Notion as a **personal and team documentation tool** in this course.

## Register and Login (10 points)
* Register on [LinkedIn](https://www.linkedin.com). 
    * Aim to connect to at least 200 people in 2 years with real people you know or meet, but don't accept any invitations blindly (the exceptions can include recruiters or NKU faculty members).
    * Upload your information, including summary, experiences, education history, and awards. 
* Use your [GitHub](https://github.com) GitHub Educational account to use GitHub [CoPilot](https://github.com/features/copilot/) free. 
    * Use [quick start](https://docs.github.com/en/copilot/quickstart) as a starting point. You need to verify your student status to use CoPilot for free. 
* Register on [ChatGPT](https://chat.openai.com/). 
* Register on [Overleaf](https://www.overleaf.com). 

## Write a CV and Resume (20 points)
* Understand the difference between CV and Resume. 
    * Use ChatGPT or Google it with the question, "What's the difference between a resume and a CV."
* Learn the format for a CV or resume.
    * Use ChatGPT or Google it with the question "How to write an example resume for a junior software engineer." 
    * You also can use the example in the reference directory. 
* Write a full CV. You can use any format, but it needs to look professional.
    * If necessary, use [Overleaf resume/CV page](https://www.overleaf.com/gallery/tagged/cv).
    * If necessary, use [MS Word Resume Template](https://templates.office.com/en-us/resume-templates).
* Make a one-page resume from the CV.
* Revise your LinkedIn using the CV. 

## Plan for the SE books to read this semester (10 points)

Use the related Canvas page `Books to read` for the list of books.

* Make a plan to read at least three books during this semester. Use the `Canvas/Books to Read` page for book covers. 
    * MMM (Mythical Man Month)
    * One of the SE `must read` section books (PP, CC, or CoCo).
    * One of the SE `recommend to read` section books
    * One of the `fun to read` section books (read at least only one chapter). 
* Use MS Word or markdown file to make a schedule with the following information.
    * What book to read with a deadline.
    * Milestones: a chapter with a date to finish reading the chapter. 
    * An executive summary (You write it down as a part of HW4).
    * A list of aha moments (You write it down as a part of HW4).
* Writing (a) an executive summary, (b) a list of your `aha moments`, and (c) progress report will be a part of HW4. 
* Points will be deducted when a student cannot follow the plan. 

## Be ready for ASE 485 (10 points)
* Make a MS-Word or markdown file, and use it for this assignment. 
* Define your software engineering and software design.
* List all the SE rules that you **have used** so far. List SE rules that you know (but have not used yet).
* List the SE tools that you have used. 
* Keep adding the rules you have used (and will use) and tools for the rest of your career to be an effective problem solver with the title `software engineer`. 
